# Handoff: Dorna Workspace GUI redesign

## Files in this handoff
| File | What it is |
|---|---|
| `Desktop Mode.dc.html` | Workspace page — viewport, tool rail, side panel, setup, report |
| `Pendant Mode v3.dc.html` | Operator pendant — tabs, hold gestures, pre-flight, launch sequence |
| `Workspace UI Redesign.dc.html` | Foundations, Dashboard, Home, Scene Builder, Schedule, Components |
| `support.js` | Runtime the three files need; keep alongside them |
| `original-screenshot.png` | The shipped UI these replace |

Open any `.dc.html` directly in a browser — no build step. The spec below is the
source of truth where a design file and this document disagree.

Repo: `dorna-robotics/workspace`, branch `pendant`, scope `workspace/gui/`.
Nothing in this package has been committed. It is design intent plus the exact
changes to make.

## Read this first

The repo already has a real design system: `docs/design-system.md` + tokens in
`workspace/gui/vendor/base.css`. **The redesign does not replace it.** It:

1. **Re-values existing tokens** (color + font family). No token is renamed,
   no token is added except three documented ones.
2. **Keeps every class name, structure and rule** in `base.css`, `nav.css`,
   `admin/style.css`.
3. **Changes behavior in three specific places** (§4). Those are the only
   places where markup/JS changes.

If a diff touches a class name or a selector, it has gone further than
intended. The whole visual change should land in `:root` /
`[data-theme="light"]` in `base.css` plus the three behavior fixes.

Design files (open in a browser):

- `Workspace UI Redesign.dc.html` — token map, dashboard, pendant rail,
  shared primitives, in both themes.
- `Desktop Mode.dc.html` — the workspace detail page, fully designed.
- `Pendant Mode v3.dc.html` — the pendant operator layout.

---

## 1. Token re-values

Replace the color and font values in `base.css`. Everything else in the file —
radius scale, spacing scale, type scale, motion tokens, every rule below the
`:root` blocks — stays exactly as it is.

### Dark (`:root`)

```css
--bg:         oklch(0.19 0.012 255);
--surface:    oklch(0.235 0.014 255);
--surface2:   oklch(0.28 0.015 255);
--surface3:   oklch(0.33 0.016 255);
--border:     oklch(0.38 0.018 255);
--border2:    oklch(0.3 0.014 255);
--text:       oklch(0.95 0.006 255);
--muted:      oklch(0.7 0.01 255);
--muted2:     oklch(0.67 0.012 255);
--accent:       oklch(0.74 0.14 250);   /* text / interactive */
--accent-solid: oklch(0.54 0.19 258);   /* fills under white text */
--accent-h:   oklch(0.82 0.12 250);
--accent-dim: oklch(0.34 0.075 255);
--green:      oklch(0.72 0.16 152);
--red:        oklch(0.7 0.18 27);
--amber:      oklch(0.78 0.14 75);
```

### Light (`[data-theme="light"]`)

```css
--bg:         oklch(0.945 0.004 250);
--surface:    #ffffff;
--surface2:   oklch(0.965 0.004 250);
--surface3:   oklch(0.925 0.006 250);
--border:     oklch(0.86 0.008 250);
--border2:    oklch(0.92 0.006 250);
--text:       oklch(0.24 0.015 250);
--muted:      oklch(0.5 0.013 250);
--muted2:     oklch(0.53 0.013 250);
--accent:       oklch(0.52 0.17 250);   /* text / interactive */
--accent-solid: oklch(0.52 0.17 250);   /* fills under white text */
--accent-h:   oklch(0.45 0.17 250);
--accent-dim: oklch(0.94 0.04 250);
--green:      oklch(0.52 0.14 152);
--red:        oklch(0.5 0.18 27);
--amber:      oklch(0.52 0.13 70);
```

### `--accent` splits in two

`--accent` does two incompatible jobs: it is a **solid fill under white text**
(`.btn-primary`, the nav count badge) and it is **text on `--accent-dim`**
(`.app-nav-link.active`, the READY pill). Those pull lightness in opposite
directions — in dark theme, text wants to go lighter while the fill wants to go
darker — so one value cannot satisfy both. At a single value, white on
`--accent` measures 3.11:1 in dark.

Split it: `--accent` for text and interactive colour, `--accent-solid` for
fills that carry white text. In light theme they land on the same value; keep
both names anyway so the dark override has somewhere to go.
`Pendant Mode v3.dc.html` already works this way.

### Three new tokens

`base.css` currently hardcodes `rgba()` state tints in ~30 rules
(`.pill.ok`, `.toast.bad`, `.btn-danger`, `.confirm-ok-danger`, `.wc-err`,
`.devices-meta--warn`, …) — each duplicated for light theme. Add the dim
companions and point those rules at them. This is the one place the token set
grows, and §6 of the design-system doc allows it with a documented reason:
the reason is that a re-value currently requires editing thirty literals.

```css
/* dark */
--green-dim: oklch(0.32 0.07 155);
--red-dim:   oklch(0.3 0.06 25);
--amber-dim: oklch(0.31 0.055 70);
/* light */
--green-dim: oklch(0.95 0.04 152);
--red-dim:   oklch(0.96 0.035 27);
--amber-dim: oklch(0.96 0.045 80);
```

Then, for example: `.pill.ok { background: var(--green-dim); color: var(--green); }`
and **delete** the `[data-theme="light"] .pill.ok` override — it becomes
redundant. Same pattern for `.pill.warn/.bad`, `.toast.ok/.warn/.bad`,
`.btn-danger`, `.confirm-ok-danger`, `.devices-count` variants, `.wc-err`.
Expect the light-theme override block to shrink by roughly half.

Keep `--sim` as its own hue; it is explicitly not a state colour. Re-valued:
`oklch(0.72 0.13 285)` dark, `oklch(0.52 0.16 285)` light. Add `--sim-dim`
(`oklch(0.31 0.06 285)` / `oklch(0.95 0.035 280)`).

### `.btn-warn` — the fourth new token

`.btn-warn` (Park) is currently a hardcoded `#ff7a3f` / `#d8651e`, not a token
reference — the same problem as the `rgba()` tints, one rule instead of thirty.
It is deliberately *not* `--amber`: amber means "degraded / check", Park is an
action. Give it its own name so the distinction survives:

```css
/* both themes */ --orange: oklch(0.58 0.17 50);
```

One value for both themes, deliberately: `.btn-warn` is a solid fill under white
text, so its requirement (white ≥ 4.5:1) does not change with the surface behind
it.

**Amber and orange are not one ramp.** An earlier draft of this spec tried to
make amber → orange → red a single monotonic lightness ladder; that is wrong,
because the three play two different roles that pull lightness in opposite
directions. `--amber` and `--red` are *text on a tint* (light theme wants them
darker); `--orange` is a *solid under white text* (dark theme wants it darker).
Separate them by **hue**, and let contrast set lightness independently:

| pair | light | dark |
|---|---|---|
| `--text` on `--surface` | 16.43 | 14.48 |
| `--muted` on `--surface` | 5.98 | 6.27 |
| `--muted` on `--surface2` | 5.41 | 5.49 |
| `--muted2` on `--surface` | 5.25 | 5.60 |
| `--muted2` on `--surface2` | 4.75 | 4.90 |
| `--accent` on `--surface` | 5.43 | 7.28 |
| `--accent` on `--accent-dim` | 4.55 | 5.10 |
| white on `--accent-solid` | 5.43 | 5.18 |
| `--green` on `--green-dim` | 4.50 | 5.28 |
| `--amber` on `--amber-dim` | 4.99 | 6.50 |
| `--amber` on `--surface` | 5.66 | 8.19 |
| `--red` on `--red-dim` | 5.71 | 4.82 |
| `--red` on `--surface` | 6.60 | 5.77 |
| `--sim` on `--sim-dim` | 4.99 | 5.25 |
| white on `--orange` | 4.55 | 4.55 |

Every pair is ≥ 4.5:1 (WCAG AA) at the size it is actually used, in both
themes. `--muted2` is the search placeholder — real text — and is measured
against `--surface2`, the tighter of its two backgrounds. This closes the
"`--muted` contrast audit pending" item in `design-system.md` §15.

**The workspace page carries a second map** (`--fg/--fg2/--fg3/--fg4`,
`--panel`, `--subtle`, `--chip`, tints) because it predates the shared one.
It has now been audited to the same standard and needed the same two
structural fixes: `--fg4` lifted off tinted backgrounds, and **`--accent` and
`--ok` split into text and `-solid` fill variants** — white on dark-theme
`--accent` measured 3.11 and on `--ok` 2.15. When these two maps are merged
into `base.css`, merge the names too: one `--muted2`, one `--accent` /
`--accent-solid`, one `--green` / `--ok-solid`.

Disabled controls are exempt: they are ghosted per `design-system.md` §4
(`opacity` + `grayscale` + `not-allowed`), which WCAG excludes from contrast
minimums.

### The two rules that every failure in this design came from

Both are worth enforcing in `base.css` rather than rediscovering per page:

1. **A colour that is text on a tint and also a fill under white text needs two
   tokens.** They pull lightness in opposite directions — the text form wants
   darker in light theme, the fill form wants darker in dark theme. Every
   contrast failure found across three files was this: `--accent`, `--ok`,
   `--amber`/`--orange`. Each is now `X` (text) and `X-solid` (fill).
2. **Retuning one value means re-measuring the whole table.** Fixing amber
   against its tint pushed it onto orange; fixing orange against amber pushed
   it onto red. Measure the set, not the pair.

### Icons: one weight, everywhere

All three design files were normalised to `stroke-width="2"` with round cap and
join. The only exception is an illustration rendered above icon size — the
`.viewer-placeholder` mark at 40 px carries `stroke-width="1.2"` so its
*effective* stroke lands at 2 px. The rule is optical weight at the rendered
size, not the authored number.

Hue separation carries state meaning where lightness cannot: amber 70° →
orange 50° → red 27°, roughly 20° on each side. §4.3 puts an orange "Recover
all" inside an amber banner and the pendant rail puts orange Park above red
Kill, so both gaps have to hold.

**If you retune any value, re-measure the whole table.** Every contrast failure
found during this design came from tuning one pair in isolation.

Then `.btn-warn { background: var(--orange); color: #fff; }` and delete the
`[data-theme="light"] .btn-warn` override.

### Fonts

```css
--font: Barlow, -apple-system, system-ui, sans-serif;
--mono: "IBM Plex Mono", ui-monospace, SFMono-Regular, Menlo, monospace;
```

Self-host both — the GUI runs on a local web server on the robot controller
with no internet. Put woff2 files in `workspace/gui/vendor/fonts/` and add
`@font-face` at the top of `base.css` (weights 400/500/600/700 for Barlow,
400/500/600 for Plex Mono). Do not add a Google Fonts `<link>`; it will hang
on an offline controller.

Barlow's x-height runs slightly larger than SF Pro at the same px. The type
scale does not change, but check `--text-xs` (11px) tracked-caps labels once
in the browser.

### Icons

Unchanged, and that is a rule, not an omission. The app uses feather at a
single weight: inline SVG, 24px viewBox, `currentColor`, `stroke-width="2"`
with `stroke-linecap="round" stroke-linejoin="round"`. Reuse the exact markup
already in `admin/index.html` and `vendor/theme.js` — do not redraw an icon by
hand. A second stroke weight anywhere reads as a second icon set.

---

## 2. Dashboard — `admin/index.html` + `dashboard.js`

The card keeps its flat surface and 3 px state rail. Three changes:

**Name and state share a line.** `.wc-name` currently holds name + `.wc-label`;
move the status `.pill` into that flex row so the operator reads
"what is it / what is it doing" in one fixation. `.wc-path` drops to
`--muted` at `--text-sm` on the line below.

**One primary action per card, labeled by state.** Today the footer renders a
fixed set of buttons and disables the ones that don't apply. Replace with a
single `.btn-primary` whose label is derived from state:

| State | Primary label | Variant |
|---|---|---|
| `IDLE` / not launched | Launch | `.btn-primary` |
| `READY` | Start | `.btn-primary` |
| `RUNNING` / `ACTIVE` | Pause | `.btn-primary` |
| `PAUSED` | Resume | `.btn-primary` |
| `ERROR` | Recover | `.btn-danger` |

Then `Pendant` as `.btn` and `Kill` as `.btn-ghost` with `--red` text, pushed
right. Everything else moves into the card's overflow menu or the detail page.

**Stats bar loses its boxes.** Keep the filter behavior and the `::before`
accent on the active item; render the five items separated by hairlines on
`--surface` rather than five bordered tiles. Values stay mono + tabular-nums.

Empty state, search, and both modals are unchanged apart from tokens.

---

## 3. Workspace detail — `admin/workspace.html` + `workspace.js`

Designed in full in `Desktop Mode.dc.html`. Structure, left to right:
48 px app nav (existing `nav.css`, unchanged) → 336 px control panel →
3D viewport with a 36 px axis ribbon pinned at its bottom.

### The 3D viewer is switchable at runtime

The workspace viewer is an iframe with real cost — GPU, bandwidth over VNC, and
CPU on a shared bench — so the operator can **turn it off and on**. This is a
setting they own, not a build-time capability, and it lives in **two places on
purpose**:

1. **The eye button in the viewport tool rail** — top-right of the canvas,
   matching the shipped app's rail: **separate** 34 px rounded buttons stacked
   with an 8 px gap, each its own `--panel` card with a hairline border and
   `--shadow-sm` (not one grouped segmented block), active state = accent tint
   + accent border (`--accent`, not a tinted hairline — the tint alone is too
   quiet to read as state). A camera-reset home button sits detached at the
   rail's foot, as in the shipped app. The camera belongs to the viewer iframe,
   so the host posts `viewer:resetCamera` to it (`iframe[data-viewer]`) — and,
   because a host control must never depend on a child answering, it also
   confirms locally: a small "✓ camera reset" pill appears at the top of the
   viewport for 1.3 s. In this mock, where no iframe is mounted, that pill is
   the whole visible effect. The rail carries three real toggles —
   **eye** (viewer on/off; becomes eye-with-slash when off), **grid** (the
   48 px deck lattice) and **axes** (the axis ribbon) — and nothing
   decorative: a rail button that does not do something is a lie about
   capability.

   **The rail renders only where its toggles have visible effect** — 3D view,
   and only once launched. Before launch the viewport belongs to the rack
   setup (§4.5) and none of grid, axes or viewer is being drawn, so a rail
   there would let an operator flip three switches with no feedback and then
   discover the consequences after launch. A control that silently banks state
   for later is worse than no control. A viewport control belongs on the viewport, so the
   rail renders **only in the 3D view**: switch to Schedule and the rail, the
   lattice and the axis ribbon all go — Schedule carries no trace of the
   viewer, because a plan view has nothing to say about a scene. Accent-tinted
   when on, slashed cube when off. When more viewer tools land, they stack in
   this rail.

   **The toggle does not change views.** Turning the viewer off while in 3D
   view leaves you in 3D view, showing a slashed-cube empty state — "3D viewer
   is off · turned off to save bandwidth on this bench. The run is
   unaffected." — with a **Turn viewer on** button. The 3D view tab itself is
   never disabled or struck through: it is a view, always selectable, and what
   varies is what the view contains. A control that silently relocated the
   operator would be worse than one that is simply off.
2. **A "3D viewer" switch in Operator Controls**, alongside Feed hold and
   Verbose logging, for operators who look for settings where settings live.

Both drive the same state, seeded from a `viewer3d` prop for benches that
should default to off. **Not** the topbar — that group is app chrome (window,
mode, theme), and mixing a per-view control into it dilutes both.

Schedule remains its own tab throughout — it is a peer view, not a fallback,
and its presence does not depend on the viewer's state.

When the switch is off:

- The **3D view** tab stays visible but is struck through, dimmed and
  `not-allowed`, titled "Viewer is off — turn it on in Operator Controls". An
  operator who used it an hour ago must be told where it went.
- A mono chip beside the tab pair reads **"viewer off · turn on"** and is
  itself the switch — the fastest way back is at the point of absence, not
  buried in the panel that turned it off.
- **Schedule becomes the effective view**; the 48 px lattice, the axis ribbon
  and the viewer placeholder are suppressed, since each is an affordance of a
  scene that is not being drawn. Toggling back on returns to 3D view.
- Pre-flight, setup and the run report are unaffected — none of them depend on
  the viewer.

The rule generalises: when something is switched off, keep its control visible
and inert with a stated reason and a one-click way back. Silently removing
controls makes an operator doubt the machine rather than the setting.

### Viewport chrome

The workspace page does **not** own the 3D controls. `workspace.html:667` is
`&lt;iframe id="ws3dFrame"&gt;` — the viewer is embedded, and the page's own comment
notes it "keeps the iframe's internal controls (zoom, home, eye)". So there is
no tool rail, no view cube and no camera/zoom/collision readout on the host
page. After launch, show the `.viewer-placeholder` (icon · "3D Viewer" · one
hint line) until the scene loads. **Before** launch the viewport is not a
placeholder at all — it is the run setup panel; see §4.5.

The rule that decides what may sit over the viewport:

- **Machine state → host may show it.** The axis ribbon (X/Y/Z/A/B,
  `tool 1 · base 0 · live|sim`) is fed by `/orchestrator/ws/status` and
  `workspace/&lt;id&gt;/status`, which the host already subscribes to. Keep it.
- **Viewer state → it belongs to the iframe.** Camera projection, zoom ratio and
  the collision toggle live inside the viewer; `workspace.js:1810` posts theme
  *to* the iframe and nothing comes back. Rendering them on the host would mean
  inventing a two-way protocol or hard-coding strings.

Only the `3D view | Schedule` tabs sit top-left over the viewport, because the
view switch is host state.

### Header controls — two shapes, one rule

The topbar action group is the repo's, unchanged: `.topbar-actions` holds
**fullscreen then theme**, both icon-only ghost buttons, in that order, on
every page — workspace, pendant, dashboard, home, scene builder. A user should
never have to look for them.

Page-specific controls sit *before* that group and take one of two shapes:

- **Icon-only ghost** — ambient, does not change where you are: Back,
  Picture-in-picture.
- **Bordered + labelled** — changes context: `Pendant mode`, which navigates to
  the operator layout. It is the only labelled button in the header, which is
  what makes it read as the one that takes you somewhere.

An unbordered labelled button next to a bordered one reads as an oversight, so
if a new header control is added, it takes one of these two shapes — not a
third.

### Density

This page is desktop-only (mouse at ~60 cm) and must **not** inherit pendant
sizing. Concretely: header 46 px (not the shared 54 px topbar — this page
overrides), panel section headers 36 px, action buttons 34 px, body text
13 px, values 12.5 px, section labels 10 px. Touch minimums do not apply
here; `design-system.md` §10 already grants desktop-only admin 32 px.

### Panel sections, top to bottom

1. **Lifecycle** — see §4.1. Phase hint line, Launch, Start/Pause/Park row,
   Parameters + Controls row, Kill.
2. **Status** — 64 px key column, `grid`, baseline aligned: Uptime, Launched,
   Endpoint, Path. Empty values render `—`, never blank.
3. **Steps** (badge: count) — alias into the shared step-list primitive
   (`:is(.step-card, .pendant-step-card, …)` in `base.css`, per
   `design-system.md` §3.4): a circular `.step-dot` with the glow and opacity
   ladder, not a numbered square. Done rows carry a green dot at 0.85 opacity,
   the current row an accent dot with `0 0 8px` glow on an `--accent-tint`
   background, upcoming rows a muted dot at 0.4.
4. **Status** — use `.meta-list` from `base.css`: a `--surface2` block at
   `--radius-md` with hairline-separated `.meta-row`s, `.meta-key` left and
   `.meta-val` (mono, tabular) right. Rows: Uptime, Launched, Endpoint, Path.
   Empty values render `—`, never blank. Scene Builder's Selection panel
   already uses this primitive; the workspace page should not invent a second
   key/value treatment.
4. **Devices** (badge: `n/4 up`) — see §4.3.
5. **Run parameters** (badge: count) — mono key / mono value grid.
6. **Operator controls** (badge: count) — switches + speed stepper.
7. **Logs** (badge: warn count) — mono rows; warning rows get `--amber-dim`
   background plus `box-shadow: inset 3px 0 0 var(--amber)`.

Every collapsed section carries a badge. A section header with no badge gives
the operator no reason to open it.

### Two truncation constraints (both were bugs in the mockup)

- **Path** truncates from the **head**, not the tail: the project name must
  survive. `direction: rtl; text-overflow: ellipsis` on the container with an
  `direction: ltr; unicode-bidi: isolate` inner span.
- **Device identity** gets its own full-width line. Name + status dot on line
  one; status text and the Recover / SIM buttons on line two, indented 16 px.
  Sharing one flex row with two buttons leaves ~135 px for a string that needs
  150 px, and the part that gets cut (`-0`, `10.0.2.10`) is the diagnostic
  payload.

### Viewport chrome

HUD chips top-left (`--hud`: `rgba(255,255,255,0.85)` light /
`oklch(0.24 0.014 255 / 0.88)` dark — add this token). Tool rail as one
floating card top-right, 32 px buttons. View cube bottom-right at
`bottom: 58px` so it clears the ribbon — anchoring at 14 px collides.
Axis ribbon: X/Y/Z/A/B chips at `flex: none` so numbers never shrink, a
flexible spacer, then `tool 1 · base 0 · live|sim` which ellipses.

`makeRenderer()` guarding stays exactly as documented in §14b — a refused
WebGL context must leave the panel and controls fully working.

---

## 4. Behavior changes

These five are the substance of the redesign. Everything above is paint.

### 4.1 Launch is a first-class action, and the lifecycle is explicit

The current UI has no Launch control, so a workspace that has never been
launched shows Start/Hold/Park/Kill in a state where none of them do
anything useful. Model the run as an explicit phase:

```
idle → launching → ready → running ⇄ paused
                              ↓        ↓
                            parked   fault
```

| Phase | Chip | Enabled |
|---|---|---|
| `idle` | NOT_LAUNCHED | Launch only |
| `launching` | LAUNCHING (dot pulses) | nothing |
| `ready` | READY | Start, Park, Parameters, Controls, Kill |
| `running` | RUNNING (dot pulses) | Pause, Kill |
| `paused` | PAUSED | Start (labeled **Resume**), Park, Kill |
| `parked` | PARKED | Start, Kill |
| `fault` | FAULT | Recover, Kill |

Launch is the only filled button while `idle`. Once launched it demotes to a
ghost **Relaunch** — there is never more than one filled button on screen.
A one-line hint sits beside the section label ("Launch to bring the workcell
online", "Paused mid-step — Start resumes").

Uptime and Launched show `—` until a launch exists.

### 4.4 Kill is a hold, not a tap

The one deliberate moment of weight in the system. Every other control is a
tap; KILL is a **press-and-hold** — 1200 ms on the pendant, 900 ms on the
desktop page.

**Implement the charge as a CSS animation, never a JS progress loop.** The
obvious build — `setInterval` writing a progress fraction into state — repaints
the whole view 25×/s and visibly stutters on a bench tablet. Instead: one state
flip on pointer-down, and the fill is a `@keyframes holdFill` (`scaleX(0)` →
`scaleX(1)`, `transform-origin: left`) run for the hold duration with
`will-change: transform`, so the compositor owns every frame and React renders
twice per gesture instead of thirty times. Two details that matter: animate
`transform`, not `width` (width is a layout property — it cannot be
composited); and keep the `transition` used for the release **constant** in the
style object rather than adding it in the same commit as the value change, which
browsers will not animate.

While held, the button charges left-to-right with a diagonal
hazard stripe (`repeating-linear-gradient`, 135°, alternating the two danger
tokens); label and icon flip to white as the fill passes under them. Release
early and it snaps back, the label reading "HOLD TO KILL" for ~1.5 s — the
failed gesture teaches the successful one. No confirmation dialog: the hold IS
the confirmation, it works with gloves, and it cannot be triggered by a brush.
Completing the hold kills to `idle` (§4.1) and closes any open dialogs.
Keyboard: ⇧⌘K keeps requiring the same hold via key-repeat or shows the same
hint — never an instant kill from a keystroke.

**Park is the same gesture in a different key.** Park ends the run gracefully
(finish the movement, park the arm), so it is also a hold — 900 ms pendant,
700 ms desktop — with the same 135° hazard charge, but struck in the `--warn`
ramp rather than `--danger`: amber stripes for "stopping deliberately", red for
"stopping now". Its rest state is a warn-outlined button. Park and Kill are
equal-width adjacent siblings in the footer's final group (pendant:
START/RESUME · PAUSE | PARAMETERS · CONTROLS | PARK · KILL; desktop: Park and
Kill share the last lifecycle row) — neither is the default. The grammar: a
hold means consequence; the colour says how final.

The hazard stripe is reserved for these two holds. It appears nowhere else in
the system, at rest or otherwise — scarcity is what makes it read as
consequence; colour, not texture, separates graceful from destructive.

### 4.5 Pre-launch is one screen with one exit

While `idle` the page shows the run setup and nothing else. Not a modal over a
dead viewport — the setup **is** the main region, because there is no second
thing an operator could usefully do before launch, and a dialog asking
permission to show the only available screen is a step that teaches nothing.

Hidden entirely while `idle`:

| Page | Removed pre-launch |
|---|---|
| Workspace detail | the 336 px panel (lifecycle, status, steps, devices, logs), the 3D view / Schedule tabs, the axis ribbon, the viewport lattice |
| Pendant | the alert banner, the event log rail, the card grid, PAUSE · PARK · PARAMETERS · CONTROLS · KILL |

What remains: topbar (chip reads NOT_LAUNCHED, timer `--:--`), nav rail, the
setup panel, and one filled button — **Set & Launch** on the workspace page, a
full-width **LAUNCH** in the pendant footer. Everything reappears on launch.
The viewport background drops its 48 px lattice for flat `--bg` while `idle`;
the lattice belongs to the 3D scene, not to a form.

**Two pre-launch variants, keyed on whether this workspace has launched
before.** First launch (or after Edit rack) gets the full grid. A workspace that
has launched before gets a one-line summary instead — "19 tubes · 0.4 mL each",
the position list, and **Edit rack** — so the operator on run nineteen is not
re-tapping a rack they did not change. Same phase, same screen, one less step.
Persist the rack per workspace; `everLaunched` is workspace state, not session
state, so a page reload must not send a returning operator back to the grid.

**An unresolved fault from the previous run renders above the rack**, in the
`--warn` banner shape from §4.3, with an Acknowledge action. It is the one thing
that survives the pre-launch strip-down, because the moment before launch is
exactly when a decapper that was over-torque last night is worth knowing about —
and the event log that would otherwise carry it is hidden. Do not gate launch on
acknowledging it; surface it and let the operator decide.

**The setup panel is drawn as the physical rack, not a form.** The operator
confirms against the bench, so the screen mirrors it: a rack body with mono row
letters (A–D) down the left and column numbers (1–5) across the top, wells as
circles, and a hairline **FRONT · LOAD FROM THIS EDGE** rule along the bottom
edge for orientation. Well states:

- **Empty** — a hole: `--bg` fill, dashed hairline, faint inset shadow, muted
  position id.
- **Tube present** (selected) — a capped tube seen from above: `--accent-tint`
  disc, 2 px `--accent` rim, an inset ring of the panel colour between them
  (the cap-on-tube read), dispense volume in mono beneath the well.
- **Source (D5)** — same tube rendering in the `--warn` ramp, labelled SOURCE
  beneath, inert. It is always present and never selectable.

Tapping a well toggles empty ⇄ tube. Wells are 44 px on desktop and 56 px on
the pendant inside taller tap targets; the control row is 34 px / 48 px
respectively (§3 density rule). Above the rack: selected count, Select all /
Clear / Reset All. Below: the Dispense field with **Apply to selected**, which
writes that value into every selected well.

**Pre-flight runs itself.** A PRE-FLIGHT block sits between the fault banner
and the rack: five checks that begin the moment the setup screen appears and
tick in sequence (~380 ms apart) — Devices (per-device handshake), Deck (tube
count + source seated), Consumables (caps remaining, projected runs), Method
(revision + validation date), Interlock (guard closed, E-STOP clear). Row
states: pending (dashed, dimmed), checking (pulsing accent ring), pass (ok
check), warning (amber !). **Warnings never block launch; failures do** — and
until the sequence finishes, Launch is dimmed with `cursor: wait`. The header
line reads "checking n/5…" then "4 passed · 1 warning". The operator does not
run the checks; the machine proves itself while the operator confirms the rack.

**The run is estimated before it starts.** The Tubes-to-process header carries
"≈ N min" (per-tube estimate × selected count — the real implementation should
derive per-tube time from the method's step chain). During the run the same
number becomes an ETA: a mono "ETA mm:ss" beside uptime on the desktop topbar,
and a small "−mm:ss left" under the elapsed timer in the pendant state block.

**Launch is a sequence, not a cut.** `launching` gets its own interstitial in
the main region (pendant: between header and footer): a small surface card,
"BRINGING WORKCELL ONLINE", one mono row per device connecting in order —
pulsing accent ring → solid ok dot + UP, ~420 ms apart — then a final
scene/workspace sync row, then `ready`, with the next screen entering on a
0.3–0.45 s fade-up. Total ~2.3 s. The point is trust: the operator watches
the machine prove each dependency rather than experiencing a hard swap. During
the sequence the footer/sidebar launch control reads LAUNCHING…, stays
accent (not ok green — nothing is running yet), and is inert.

**A run ends in a report, not a shrug.** New phase `complete` (chip: COMPLETE,
ok ramp): the main region becomes the run report — stat cells (processed / ok /
warnings / avg per tube), the rack redrawn with per-tube outcomes (green ring
ok, amber ring + measured value for warnings, source unchanged), and any
warning spelled out in a `--warn` banner with the affected position bolded.
Actions: Export report (ghost) and New run (primary; pendant footer becomes a
single full-width NEW RUN). New run returns to `idle`, which re-runs
pre-flight. The phase table in §4.1 gains: `complete` | COMPLETE | New run,
Export, Kill.

**After** launch the same panel becomes a modal, reached from Parameters — at
that point the viewport is live and editing parameters is an interruption of
something the operator is watching, so it must overlay and return. Its primary
button reads **Set & Apply**, not Set & Launch. This is the one place in the
redesign where the same content is deliberately presented two ways; the trigger
is the phase, not the viewport.

### 4.2 Hold becomes Pause, and Start becomes Resume

"Hold" is ambiguous — feed hold, safety hold, or pause? It is a pause.
Rename the control and its handler. When phase is `paused`, the Start button's
label becomes **Resume**; it is the same button and the same slot, so muscle
memory holds. Do not ship Start and Resume as two buttons where one is always
dead.

`Feed hold on scan fail` in Operator Controls keeps its name — that one really
is a feed hold.

### 4.3 Device recovery is one action, not four

When devices are down, render one banner above the list —
"N device(s) not connected" with **Recover all** (`.btn-warn`) and
**Simulate** (`.btn` ghost on `--amber` border) — rather than repeating a
Recover button on every failed row. Per-row Recover stays for the
one-off case. Recover transitions the row through a `connecting` state
(dot pulses at 0.9 s, meta reads "connecting…") before `up`; silent latency
is a defect per §8 of the design-system doc.

Row states: `up` → `--green` / "connected · 12 ms"; `connecting` →
`--amber` / "connecting…"; `down` → `--red` / "connect failed" on a
`--red-dim` row; `sim` → `--sim` / "simulated".

---

## 5. Pendant — `.pendant-overlay` in `workspace.html`

**This supersedes `design-system.md` §4.1's left-rail layout.** §4.1 puts the run
controls in a fixed 224 px left rail with the state pill leading them, and a
bottom-bar fallback below 860 px. This design uses **the bottom bar at every
width** instead. Update §4.1 when this lands — do not build both.

Why the bar won:

- The card grid is the operator's content and it wants width. A 224 px rail
  costs a full card column at 1280 px, which is where this runs.
- On a bench tablet the bar sits where hands already rest. A left rail puts the
  most-pressed control at the far edge of a two-handed reach.
- The state pill does not need to lead the controls, because the run state is
  already the largest element on screen — a solid colour block filling the
  navbar, readable across the room. §4.1's argument for co-locating them was
  that cause and action should share one glance; a navbar-wide state block
  satisfies that without spending a column.

**What §4.1 gets right and this keeps:** the navbar is the shared 54 px topbar
height — no pendant override — with the workspace name and bench id on one
line, the run state and timer as one solid block, and actions right. Every
control in the bar is one shape and one size — six equal-flex buttons, same height, same radius, icon and label
on one axis. Colour is the only thing that separates them, so an odd-one-out
reads as a mistake rather than as emphasis. Park and Kill are adjacent by
design (§4.4); what prevents a mis-tap is not distance but state — neither is
filled at rest (Park carries a warn outline, Kill a danger outline) and both
require a press-and-hold, so a brush cannot fire either. Targets stay ≥ 56 px,
and `.pendant-btn` keeps
`--radius-xl` (22 px) — the "big touch target, not a normal button" cue.

Order: **START/RESUME · PAUSE** | divider | **PARAMETERS · CONTROLS** | divider
| **PARK · KILL**. All six are `.pendant-btn`, so all six take the uppercase tracked label
§4 permits on that class — mixed casing across one control group reads as two
groups. The first slot is one button whose label follows state (LAUNCH when
idle, START when ready, RESUME when paused); the inactive controls are ghosted
in place per §4, never removed.

The rail spec in `design-system.md` §4.1 is superseded (see above). What carries
over unchanged: 0.93 scale on `:active` in 50 ms, disabled = ghosted and in
place, and `.pendant-btn` at **`--radius-xl` (22 px)**, not `--radius-lg`.
That radius is reserved for exactly this and carries the "big touch target, not
a normal button" cue — rendering these controls at the ordinary card radius
erases the only shape signal separating pendant controls from desktop ones.

Changes:

- Start / Resume is one slot (same rule as §4.2).
- Launch appears in the rail when the workspace is not launched, taking the
  Start slot.
- **The main region is a top tab strip + pinned hero, not a tile dashboard.**
  A full-width tab strip sits at the very top of the region (52 px rows, 60 px
  gloved; tracked uppercase; active tab = accent text + 3 px inset underline —
  no pills). **The tab set is dynamic**: it is derived from the running
  program's card groups (currently PRODUCTION → throughput/rack/consumables
  and SYSTEM → system/devices/I-O/chamber), so a different method may mount
  more or fewer tabs; left-aligned so added tabs extend naturally. Below the
  strip, ACTIVE ROUTINE is pinned full-width — run state never hides behind a
  tab — then the active tab's cards render large: at 1 m, two big surfaces
  beat six small tiles (the UR/KUKA pendant pattern). Tabs are the only
  layout — the earlier card-grid with hero promotion, per-card move/resize
  toolbars and an "Arrange" tray has been removed, not hidden behind a flag.
  An operator at a bench does not arrange their own dashboard mid-run, and a
  second layout doubles every state to test for a customisation nobody asked
  for.
- **Footer is the lifecycle, nothing else:** START/RESUME · PAUSE, a hairline
  divider, PARAMETERS · CONTROLS, a second divider, then **PARK · KILL**. Speed,
  Setup and Jog are removed — speed override belongs in Operator Controls (it is
  a setting, not a run control), and Setup/Jog are engineer tasks that belong on
  the workspace page. Park and Kill are deliberately adjacent as the closing
  group (§4.4): both are holds, and pairing them makes "how do I end this run"
  one place to look. Neither is filled at rest — Park carries a warn outline,
  Kill a danger outline — so adjacency never becomes a mis-tap risk. **While `idle` the footer is LAUNCH alone,**
  full-width — the other five are not ghosted but absent, per §4.5.
- Pendant targets stay ≥ 56 px. **Do not** propagate the desktop density from
  §3 here — the two densities are deliberate, not an inconsistency. Enforce this
  in `base.css` as two token sets (`--control-h` / `--font-body` scoped under
  `.pendant-overlay`), never as per-page overrides — a per-page rule is how the
  two densities will silently converge on the third page someone touches. Gloves and
  a 1 m viewing distance drive the pendant; a mouse at 60 cm drives the desktop.
- **Removed from the header:** the GLOVES toggle, E-STOP, and the ETA and
  OPERATOR stats. E-STOP is hardware on this bench, and a soft copy of a
  hardware safety control is worse than none — it invites an operator to reach
  for the screen. Glove mode survives as a setting, not a header button.
  CYCLES stays; ETA was derived and OPERATOR was not being used to make a
  decision.
- **Added:** a fullscreen toggle beside the theme toggle, using the same
  expand/shrink icon swap `vendor/theme.js` already implements for
  `.js-fullscreen-toggle`. The pendant runs on a wall tablet; it is the surface
  that most needs fullscreen and was the only one without it.
- **Exit** is a labelled control (icon + "EXIT"), not a bare chevron, and it
  returns to the workspace page.
- **Dark theme.** The pendant had no dark mode; it does now. Every colour in it
  is a token — there is not one hardcoded value left outside the two theme maps,
  which is the state `base.css` should reach too. The only literals that stay
  are `#fff` used as text/icon on a saturated fill (Start, E-STOP, the state
  block), which is correct in both themes.
- The exit control reads **EXIT**, not a bare chevron. Fullscreen and theme stay
  icon-only in `.topbar-actions` exactly as the repo has them, with
  `theme.js`'s existing `title` swap carrying the direction.

`Pendant Mode v3.dc.html` also contains a configurable card grid, hero card
promotion, attention banners, and glove mode. Those are proposals, not part of
this pass — treat them as a separate ticket.

---

## 6. Home, Scene Builder, Schedule

### Home — `server.py` `LandingHandler`

Each launcher card gains a live status chip: Orchestrator shows the running
count (same `/orchestrator/ws/status` feed `nav.js` already uses for the nav
badge), Dorna Lab shows reachable / unreachable. A launcher that cannot tell
you a service is down sends the operator to a blank page to find out.

Dorna Lab stays a plain outbound link — it is separate software and is not
designed here. Developer tools keep their progressive disclosure; the toggle
becomes a real button rather than a text row.

### Scene Builder — `scene_builder/web/index.html`

Two changes; everything else (resize handle, Insert as the only filled button,
Recipes, viewer chrome) is unchanged.

- **Objects rows get a visibility toggle** with a slashed-eye icon and
  strikethrough name when hidden. Per §9, a state carried by colour also
  carries a shape — "hidden" previously had neither, only reduced opacity.
- **Config** replaces the stacked files-list + two scope buttons with one
  segmented control over a single YAML pane. The scope choice is binary, and
  two adjacent button groups doing related jobs read as one crowded control.

Viewer chrome (`#ctrlPanel`, `#viewCubeWrap`, `#infoBar`) matches §3 exactly —
one grammar for every 3D surface so nothing needs relearning between Scene
Builder and the workspace viewer.

### Schedule — `admin/schedule.js`

**Each capsule carries its own time, not just its width.** A Gantt bar's length
already encodes duration, but at these widths a 1.9 s block and a 2.4 s block
are visually identical — so every block prints its number inside itself,
right-aligned in mono tabular: elapsed for `done`/`running` (`2.4s`, accent),
estimated for `pending` (`~4.1s`, muted, tilde-prefixed), an em dash for
`skipped`.

**The label always wins.** On a Gantt chart the label is the primary key — a bar
reading only "1.9s" cannot be identified — so the label is `flex: none` and the
number is the element that yields. Suppress the number by the block's **measured
width**, not by its share of the timeline: each block is a size container
(`container-type: inline-size`) and a single `@container (max-width: 74px)` rule
hides the time. A percentage threshold is wrong because the same percentage is a
different pixel width in every viewport — at 388 px of track, a 14 % block is
51 px and cannot hold both. Never let the number clip: a half-rendered "3." is
worse than no number, which is why this is a display rule and not `overflow:
hidden`. Every block carries a title tooltip with the full
"label · elapsed/estimated Ns" string, so the suppressed number is still one
hover away. The
tick scale along the top stays — it answers "when", the in-capsule number
answers "how long".

**Where it lives: a second tab of the workspace page's main viewport**
(`3D view | Schedule`), not a standalone page and not a pendant card. Both
views answer "what is the cell doing right now" and both want the full width;
you rarely need them simultaneously. Switching to Schedule is also the natural
moment to release the viewer's WebGL context (§14b of `design-system.md` — the
pool is capped and this page holds several).

When Schedule is active, the 3D-only chrome hides: tool rail, view cube and the
HUD chips. The axis ribbon stays — it is machine state, not viewer chrome.

The Gantt itself:

The Gantt's four block states are carried by fill, border and opacity alone —
three variations of "how blue is it". Add a non-colour signal to each, per §9:

| state | colour | shape |
|---|---|---|
| done | `--accent-dim` fill | ✓ glyph |
| running | `--accent-dim` fill, `--accent` border | pulsing dot |
| skipped | transparent | dashed border |
| pending | transparent | solid hairline border |

Elapsed-versus-planned stays as the inner fill, so a block that ran long reads
as overrun without a fifth colour. Empty state keeps "No plan yet."

**One shared time scale across all lanes.** Blocks are positioned as
`left` / `width` percentages of the total plan duration — not flexed within
each lane — so a 20 s block is the same width in every lane, a lane that
starts late shows empty track before its first block, and idle gaps are
visible. The tick row then means something, and `sched-slice-divider` /
`sched-connector` land on the coordinates they refer to. Normalising each
lane independently under a shared tick scale misreports timing, which is the
only reason the schedule view exists.

`orchestrator/web/index.html` (Dorna Lab's viewer) is out of scope — separate
software.

### Why the schedule is not on the pendant

Four lanes of timeline blocks cannot be read at 1 m through gloves without
dropping text below the 24 px floor the pendant sets for itself. More
importantly the operator does not need planned-versus-actual across devices —
that is an engineer's question. The operator needs "what is happening and what
is next", which the Active routine card already answers: `STEP 3 / 5`, the
progress segments, the step chain, and a **NEXT** row (`recap tube 2 · ~4s`)
added for exactly this reason.

The split: **engineers get the timeline, operators get the current step.** Same
data, two different questions.

---

## 7. What is NOT designed

Every page the GUI serves is designed. What remains are the modals reached
from those pages — Add workspace, Parameters, Device detail, Confirm — which
reuse the shared shells in §5 and change by tokens alone.

`orchestrator/web/index.html` is Dorna Lab, separate software reached by a
link from Home. Not in scope.

---

## 8. Order of work

1. Token re-value + `-dim` tokens + font self-hosting in `base.css`.
   Delete the light-theme overrides that the `-dim` tokens make redundant.
2. Walk every page in both themes. Fix contrast fallout here, in `base.css`,
   not in page CSS. `design-system.md` §13.8 is right that light drifts.
3. Lifecycle phases (§4.1) in `workspace.js` — this is the largest change and
   it touches the orchestrator state model, not just the view. The pre-launch
   gate (§4.5) rides on the same phase value; build it in the same pass.
4. Pause/Resume rename (§4.2) across `workspace.js`, the pendant, and the
   dashboard card.
5. Device banner + connecting state (§4.3).
6. Dashboard card and stats bar (§2).
7. Desktop density pass on `workspace.html` (§3).
8. Truncation constraints (§3) — verify with the longest real device names,
   not the demo ones.

Then update `docs/design-system.md`: the `-dim` tokens (§2.5), the desktop
density exception (§10), and the lifecycle vocabulary (new section). §14 of
that doc says grammars get codified on sign-off — this is that.

## 9. Verification checklist

- Both themes, every page, at 1280×800 and 1920×1080.
- Longest real device name renders complete in the panel at 336 px.
- Project name survives in the Path row at 336 px.
- Every phase in §4.1 reachable, with only the listed controls enabled.
- Disabled controls still occupy their slot (ghosted, not removed).
- `prefers-reduced-motion` still kills every pulse.
- Focus ring on every new interactive element (§5.1 of the design doc).
- Offline: no network font request, no external CDN.
