# The dispatch scheduler, from the Dorna AI Builder

This folder holds one Workspace change: a new scheduler, `scheduler: dispatch`.
It comes as three complete files, with the context for reviewing them. Point
your AI at this README and the files; it can answer questions from them
together.

## Installing

The files sit at the same paths they have in the Workspace repo. Copy them over
a Workspace checkout of `main`:

| File | Change |
|---|---|
| `workspace/workspace/planner/dispatch_scheduler.py` | new |
| `workspace/workspace/bt/launcher.py` | replaces the current file; selects the scheduler from `launch.yaml` |
| `workspace/workspace/bt/replay.py` | replaces the current file; the same in the replay, and adds `--scheduler` and `--flat` |

The two changed files are Workspace `main` at `5d98822c` (2026-10-07) with only
the scheduler change applied. If your copy of `launcher.py` or `replay.py` is
newer than that, merge rather than overwrite. The changes come from Jude's fork
(`JudeL12/workspace_dev`), where they've been running under the AI builder.

It's opt-in: only a project whose `launch.yaml` says `scheduler: dispatch` gets
it. `cpsat` (the default) and `greedy` are unchanged.

## Why the AI builder needs it

The builder designs a cell from a chat. Its output is an ordinary Workspace
project that is exported and run in Workspace on the bench. Every builder
project says `scheduler: dispatch`, so official Workspace needs this before
builder projects can run on a robot.

A builder project describes **one sample's** route: steps with `pre` / `eff`
and a `duration`. Loops, retries and branches are `pre` / `eff` between
actions, never code inside one. The scheduler decides how a batch goes through
that route. So the builder needs a scheduler that:

- **runs the whole batch over the whole route,** with no phases, windows or
  hand-written cycles to write per project;
- **is built in and the same for every project.** A `launch.yaml` that names a
  project optimizer or scheduler file is refused. The builder treats it like
  motion planning: the user can't change it.

CP-SAT times a whole window up front in one model, which grows with window
width times protocol depth. That's why a big protocol gets cut into phases and
cycles by hand, which the builder can't do for each project.

## How it works

It's an event-driven simulation of the batch. At each event (the robot or a
device frees up) it takes each item's next allowed route step
(`route._next_step`) whose `pre` holds and whose resources are free.

- **Device steps** (a shake, a rest, a vortex run) start as soon as they're
  allowed, because they compete for nothing the robot needs.
- **The robot's step** is picked by one ranking, lowest key first:
  1. works at the bottleneck: the step also holds a station that has at least
     as much work left as the robot;
  2. feeds the bottleneck: the item's next step is on a device with at least
     as much work left as the robot;
  3. setup: the tool-swap seconds it needs first;
  4. feeds a device;
  5. furthest along the route;
  6. item order, then route order (deterministic).
- **It never holds one shared thing** (the hand, a seat) while waiting on
  another.

The module docstring has the details.

Measured against the CP-SAT optimum on 425 random instances, it's optimal in
53.4% of them and 1.037x the optimum on average. These ideas lost about 3% on
average and weren't adopted: always putting the station first, and making the
robot wait for a station step.

## Questions worth asking your AI

- Do `bt/launcher.py` and `bt/replay.py` still behave exactly as before for
  `cpsat` and `greedy`?
- Does `dispatch_scheduler.py` handle the route shapes Workspace's own examples
  use (subprojects, phased protocols), or only the builder's flat routes?
- Should `examples/base/launch.yaml` default to `dispatch` once it's in?
